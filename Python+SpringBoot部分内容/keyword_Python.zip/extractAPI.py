from flask import Flask, g
from flask_restful import reqparse, Api, Resource
from flask_httpauth import HTTPTokenAuth
from flask_cors import *
import mysql.connector



# Flask相关变量声明
app = Flask(__name__)
CORS(app, supports_credentials=True)
api = Api(app)

# RESTfulAPI的参数解析 -- put / post参数解析
parser_put = reqparse.RequestParser()
parser_put.add_argument("main", type=str, required=True, help="need article main")
parser_put.add_argument("title", type=str, required=False, help="need title")
parser_put.add_argument("lead", type=str, required=False, help="need lead")
parser_put.add_argument("conclusion", type=str, required=False, help="need conclusion")
parser_put.add_argument("others", type=str, required=False, help="need others")
parser_put.add_argument("weight", type=str, required=True, help="need weight")



import json
# encoding=utf-8
import jieba
import jieba.analyse
import os






# 提取title中的关键词，用于细胞词库的查询
def extractTitleKeyword(title):
    # seg_list = jieba.cut(essay[str(item)], cut_all=False)  # 分词
    tags = jieba.analyse.extract_tags(title, topK=5, withWeight=True)   # TFIDF提取标题中的关键词
    titleKeyword = []
    for i in tags:
        titleKeyword.append(i[0])
    return titleKeyword




# 两词是否存在包含关系
def isEqual(xList,y):
    for x in xList:
        if(x in y):
            return True
        else:
            return False

# print(isEqual('nihao','nihao\n'))


# 根据title的关键词，寻找是否存在相关对的字典
# 存在则加入结巴分词的自定义词典以优化其他部分的分词效果
def findRelatedDict(file,essay):
    titleKeyword = extractTitleKeyword(essay['title'])
    if(titleKeyword == None):
        return
    else:
        for word in titleKeyword:
            # 遍历文件夹
            for root, dirs, files in os.walk(file):
                # 遍历文件
                for fileName in files:
                    # 逐行读取文件内容
                    with open(os.path.join(root, fileName),encoding='utf-8') as f:
                        for line in f:
                            # 若标题关键词与字典中的值重合，则将该字典加入jieba分词
                            if(isEqual(word,line)):
                                jieba.load_userdict(os.path.join(root, fileName))
                                print('\n'+'--'*30+"FIND MATCHED DICT:\t"+'--'*30)
                                print(fileName)
                                print('--'*30+"FIND MATCHED DICT:\t"+'--'*30+'\n')

                        






# 调整关键词权重
def adjustWeight(tagsList,weight=1):
    for tag in tagsList:
        tag[1] = tag[1]*weight
    return tagsList
    
# 用于list中sort方法的排序参数key
def takeSecond(elem):
    return elem[1]


# 对文章不同结构赋予不同的关键词权重
# 正文部分的关键词提取使用textrank，其余使用tfidf
# a\b\c\d分别为titile、lead、content、conclusion部分的权重
def calcKeyword(essay,titleWeight=2,leadWeight=2,contentWeight=2,conclusionWeight=2,othersWeight=2):
    findRelatedDict('./thesaurus/',essay)
    # 删除值为null的部分
    for item in list(essay.keys()):
        if(essay[item] == None):
            essay.pop(item)

    allTagsLisst = []   # 包含所有部分关键词的list
    print('\n'+'--'*30+"ALL PART KEYWORD!"+'--'*30)
    for item in essay:
        tags = jieba.analyse.extract_tags(essay[item], topK=10, withWeight=True)
        # tags = jieba.analyse.textrank(essay[item], topK=11, withWeight=True, allowPOS=('ns', 'n', 'vn', 'v'))

        # 将tuple转换为list
        tagsList = []
        for i in tags:
            tagsList.append(list(i))

        # 为不同部分的内容添加权重
        if(item == 'title'):
            tagsList  = adjustWeight(tagsList,titleWeight)
            print('title:\t',tagsList)
        elif(item=='lead'):
            tagsList  = adjustWeight(tagsList,leadWeight)
            print('lead:\t',tagsList)
        elif(item=='content'):  
            tags = jieba.analyse.textrank(essay[item], topK=10, withWeight=True, allowPOS=('ns', 'n', 'vn', 'v'))
            for i in tags:
                tagsList.append(list(i))
            tagsList  = adjustWeight(tagsList,contentWeight)
            print('content:\t',tagsList)
        elif(item=='conclusion'):
            tagsList  = adjustWeight(tagsList,contentWeight)
            print('conclusion:\t',tagsList)
        else:
            tagsList  = adjustWeight(tagsList,othersWeight)
            print('others:\t',tagsList)
        allTagsLisst.extend(tagsList)
    allTagsLisst.sort()
    print('--'*30+"ALL PART KEYWORD!"+'--'*30+'\n')
    return allTagsLisst

# 合并文章不同部分产生的相同关键词
def mergeSameWord(essay,titleWeight=2,leadWeight=2,contentWeight=2,conclusionWeight=2,othersWeight=2):
    allTagsLisst = calcKeyword(essay,titleWeight,leadWeight,contentWeight,conclusionWeight,othersWeight)
    for tagIdx in range(len(allTagsLisst)):
        afterTagIdx = tagIdx+1
        if((tagIdx+1) == len(allTagsLisst)):
            break
        tag = allTagsLisst[tagIdx]
        afterTag = allTagsLisst[tagIdx+1]

        # print('tag = ',tag)
        # print('afterTag = ',afterTag)
        if(tag[0] == afterTag[0]):
            allTagsLisst[tagIdx+1][1] = tag[1]+afterTag[1]
            allTagsLisst[tagIdx] = ""
    for i in range(len(allTagsLisst)-1,-1,-1): 
        if allTagsLisst[i] == '':
            allTagsLisst.pop(i)
    allTagsLisst.sort(key=takeSecond,reverse=True)
    print('\n'+'--'*30+"FINAL KEYWORD!"+'--'*30)
    print(allTagsLisst)
    print('--'*30+"FINAL KEYWORD!"+'--'*30+'\n')
    
    return allTagsLisst








# 操作（post / get）资源列表
class TodoList(Resource):
    

    def get(self):
        args = parser_put.parse_args()

        # 构建新参数,无此参数则为null
        main = args['main']
        title = args['title']
        lead = args['lead']
        conclusion = args['conclusion']
        others = args['others']
        weightStr = args['weight']

        weightList =[2,2,2,2,2]
        j = 0
        for i in weightStr:            
            weightList[j] = int(i)
            j += 1


        essay = {}
        essay['main'] = main
        essay['title'] = title
        essay['lead'] = lead
        essay['conclusion'] = conclusion
        essay['others'] = others

        return mergeSameWord(essay,weightList[0],weightList[1],weightList[2],weightList[3],weightList[4])

  


    def post(self):
        args = parser_put.parse_args()

        # 构建新参数,无此参数则为null
        main = args['main']
        title = args['title']
        lead = args['lead']
        conclusion = args['conclusion']
        others = args['others']
        weightStr = args['weight']

        weightList =[2,2,2,2,2]
        j = 0
        for i in weightStr:            
            weightList[j] = int(i)
            j += 1


        # return s()

        essay = {}
        essay['main'] = main
        essay['title'] = title
        essay['lead'] = lead
        essay['conclusion'] = conclusion
        essay['others'] = others

        return mergeSameWord(essay,weightList[0],weightList[1],weightList[2],weightList[3],weightList[4])

# 设置路由，即路由地址为http://127.0.0.1:5000/users
api.add_resource(TodoList, "/users")

if __name__ == "__main__":
    app.run(debug=True)




