package com.tokii.keyword;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

// 忽略MyBATIS
//@SpringBootApplication(exclude= DataSourceAutoConfiguration.class)

//Mapper扫描（这里的值就是dao目录的值，按照我刚贴的目录结构来做就行）
@MapperScan("com.tokii.keyword.dao")
@SpringBootApplication
public class KeywordApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeywordApplication.class, args);
	}

}
