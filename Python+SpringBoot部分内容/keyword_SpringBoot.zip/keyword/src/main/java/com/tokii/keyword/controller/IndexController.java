package com.tokii.keyword.controller;

import com.tokii.keyword.dao.UserDao;
import com.tokii.keyword.domain.Article;
import com.tokii.keyword.domain.User;
import com.tokii.keyword.service.DESUtil;
import com.tokii.keyword.service.ExtractService;
import com.tokii.keyword.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@EnableAutoConfiguration
public class IndexController {
    //自动注入userService，用来处理业务
    @Autowired
    private UserService userService;
    @Autowired
    private ExtractService extractService;
    @Autowired
    private UserDao userDao;
    /**
     * 域名访问重定向
     * 作用：输入域名后重定向到index（首页）
     * */
    @RequestMapping("")
    public String index(HttpServletResponse response) {
        //重定向到 /index
        return response.encodeRedirectURL("/index");
    }
    /**
     * 首页API
     * 作用：显示首页
     * */
    @RequestMapping("/index")
    public String home() {
        //对应到templates文件夹下面的index
        return "index.html";
    }
    /**
     * 注册API
     * @method：post
     * @param user（从View层传回来的user对象）
     * @return 重定向
     * */
//    @RequestMapping(value = "/register", method = RequestMethod.POST)
//    public String registerPost(Model model,
//                               //这里和模板中的th:object="${user}"对应起来
//                               @ModelAttribute(value = "user") User user,
//                               HttpServletResponse response) {
//            //我们可以用Sout这种最原始打印方式来检查数据的传输
//            System.out.println("Controller信息:"+user.getUsername());
//            System.out.println("Controller密码:"+user.getPassword());
//            //使用userService处理业务
//            String result = userService.register(user);
//            //将结果放入model中，在模板中可以取到model中的值
//            //这里就是交互的一个重要地方，我们可以在模板中通过这些属性值访问到数据
//            model.addAttribute("result", result);
//            //开始重定向，携带数据过去了。
//            return response.encodeRedirectURL("/index");
//    }
    @ResponseBody
    @GetMapping(value = "/register")
    public String register(@RequestParam(value = "name", required = true) String name,
                           @RequestParam(value = "pwd", required = true) String pwd) {
        //register_check是自定义的一个注册方法我们可以在里面写注册操作，返回状态码
        System.out.println("用户名："+name);
        System.out.println("密码："+pwd);
        User user = new User(name,pwd);
        String result = userService.register(user);
        System.out.println("结果："+result);
        return result;
    }
    /**
     * 登录API
     * @method：post
     * @param user（从View层传回来的user对象）
     * @return 重定向
     * */
//    @RequestMapping(value = "/login", method = RequestMethod.POST)
//    public String loginPost(Model model,
//                            @ModelAttribute(value = "user") User user,
//                            HttpServletResponse response,
//                            HttpSession session) {
//        String result = userService.login(user);
//        if (result.equals("登陆成功")) {
//            //session是作为用户登录信息保存的存在
//            session.setAttribute("user",user);
//        }
//        model.addAttribute("result", result);
//        return response.encodeRedirectURL("/index");
//    }
    @ResponseBody
    @GetMapping(value = "/login")
    public String login(@RequestParam(value = "name", required = true) String name,
                           @RequestParam(value = "pwd", required = true) String pwd,
//                            HttpSession session) {
                        HttpServletResponse response) {
        System.out.println("用户名："+name);
        System.out.println("密码："+pwd);
        User user = new User(name,pwd);
        String result = userService.login(user);
        if (result.equals("102")) {
            // session是作为用户登录信息保存的存在
            // session.setAttribute("user",user);

            // MD5
            String username_md5 = DigestUtils.md5DigestAsHex(name.getBytes());
            System.out.println("md5Name:"+username_md5);
            // AES
            String username_AES = DESUtil.getEncryptString(name);
            // 创建一个 cookie对象
//            Cookie cookie = new Cookie("name", username_md5);
            Cookie cookie = new Cookie("name", username_AES);
            //存在时间，单位为秒，下边表示存1天
            cookie.setMaxAge(60*60*24);
            //将cookie对象加入response响应
            response.addCookie(cookie);
        }
        System.out.println("结果："+result);
        return result;
    }
    /**
     * 注销API
     * @method：get
     * @return 首页
     * */
    @RequestMapping(value = "/loginOut", method = RequestMethod.GET)
    public String loginOut(HttpSession session) {
        //从session中删除user属性，用户退出登录
        session.removeAttribute("user");
        return "index";
    }

    /**
     * 接收要提取关键字文章的结构
     * @method：get
     * @return 首页
     * */
    @ResponseBody
    @GetMapping(value = "/test")
    public String extract(@CookieValue(value = "name",
            defaultValue = "none") String username) {
        System.out.println("---------------------------");
        if(username!="none"){
            System.out.println(username);
            String username_Decrypt = DESUtil.getDecryptString(username);
            User x = userDao.getOneUser(username_Decrypt);
            if(x != null){
                System.out.println(x);
            }


        }
        return username;
    }


    /**
     * 请求pythonAPI，获得关键字
     * @method：get
     * @return 首页
     * */
    @ResponseBody
    @GetMapping(value = "/extract")
    public List test(Article article,@CookieValue(value = "name",
            defaultValue = "none") String username) {
        ArrayList<String> b = new ArrayList<>();
        b.add("illegal user! LOGIN FIRST!!!");
        // 确认当前用户权限
        if(!"none".equals(username)){
            String username_Decrypt = DESUtil.getDecryptString(username);
            User x = userDao.getOneUser(username_Decrypt);
            if(x != null){
                Map<String,String> map = new HashMap();
                map.put("main",article.getMain());
                map.put("weight",article.getWeight());
                map.put("lead",article.getLead());
                map.put("title",article.getTitle());
                map.put("others",article.getOthers());
                map.put("conclusion",article.getConclusion());

                RestTemplate restTemplate = new RestTemplate();
                String url = "http://127.0.0.1:5000/users?main={main}&lead={lead}&weight={weight}&title={title}&conclusion={conclusion}&others={others}";
                List keywordList = restTemplate.getForObject(url,List.class,map);
                return keywordList;
            }else{
                return b;
            }
        }else {
            return b;
        }




    }
}