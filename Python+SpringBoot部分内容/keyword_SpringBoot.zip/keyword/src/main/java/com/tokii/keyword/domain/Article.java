package com.tokii.keyword.domain;

//@Data
//@ToString
public class Article {




    private String main;
    private String lead;
    private String title;
    private String conclusion;
    private String others;
    private String weight;

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }




    public String getMain() {
        return main;
    }

    public void setMain(String main) {
        this.main = main;
    }

    public String getLead() {
        return lead;
    }

    public void setLead(String lead) {
        this.lead = lead;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getConclusion() {
        return conclusion;
    }

    public void setConclusion(String conclusion) {
        this.conclusion = conclusion;
    }

    public String getOthers() {
        return others;
    }

    public void setOthers(String others) {
        this.others = others;
    }

    @Override
    public String toString() {
        return "Article{" +
                "main='" + main + '\'' +
                ", lead='" + lead + '\'' +
                ", title='" + title + '\'' +
                ", conclusion='" + conclusion + '\'' +
                ", others='" + others + '\'' +
                ", weight='" + weight + '\'' +
                '}';
    }

}
