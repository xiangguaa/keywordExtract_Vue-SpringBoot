package com.tokii.keyword.service;

import com.tokii.keyword.domain.Article;
import org.springframework.stereotype.Service;

@Service
public class ExtractService {
    public Article extract(Article article){
        System.out.println("EXTRACT SSSSERVICE");



        return article;
    }
}
