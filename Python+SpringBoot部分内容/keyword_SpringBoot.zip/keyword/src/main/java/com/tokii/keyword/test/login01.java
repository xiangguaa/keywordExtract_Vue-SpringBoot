package com.tokii.keyword.test;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
@RequestMapping("/login01")
public class login01 {

    @GetMapping()
    public String normal()
    {
        return "hello ????";
    }



}
