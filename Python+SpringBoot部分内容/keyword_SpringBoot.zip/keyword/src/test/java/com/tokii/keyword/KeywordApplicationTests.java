package com.tokii.keyword;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeywordApplicationTests {

	@Test
	void contextLoads() {
	}

}
